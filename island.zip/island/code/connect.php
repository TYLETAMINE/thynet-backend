<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name = 'island';

$conn = mysqli_connect($host, $user, $pass, $name);